import pyspark
from pyspark.sql import functions as f

# spark session
spark = SparkSession.builder.appName("SparkFundamentalsHomework").getOrCreate()

# read data
matches_df = spark.read.option("header", True).csv("/home/iceberg/data/matches.csv")
matches_details_df = spark.read.option("header", True).csv("/home/iceberg/data/match_details.csv")
medals_matches_players_df = spark.read.option("header", True).csv("/home/iceberg/data/medals_matches_players.csv")
medals_df = spark.read.option("header", True).csv("/home/iceberg/data/medals.csv")
maps_df = spark.read.option("header", True).csv("/home/iceberg/data/maps.csv")

# create bucketed tables to join
# matches
spark.sql(
    """
        CREATE TABLE IF NOT EXISTS bootcamp.matches_bucketed(
            match_id STRING,
            completion_date DATE,
            mapid STRING,
            playlist_id STRING
        )
        USING iceberg
        PARTITIONED BY (completion_date, bucket(4, match_id));
    """
)

# match_details
spark.sql(
    """
        CREATE TABLE IF NOT EXISTS bootcamp.matches_details_bucketed(
            match_id STRING,
            player_gamertag STRING,
            player_total_kills INTEGER
        )
        USING iceberg
        PARTITIONED BY (bucket(4, match_id));
    """
)

# medals_matches_players
spark.sql(
    """
        CREATE TABLE IF NOT EXISTS bootcamp.medals_matches_players_bucketed(
            match_id STRING,
            player_gamertag STRING,
            medal_id STRING,
            medal_count INTEGER
        )
        USING iceberg
        PARTITIONED BY (bucket(4, match_id));
    """
)

# populate tables
# matches
matches_df.select(
    "match_id",
    f.to_date("completion_date").alias("completion_date"),
    "mapid",
    "playlist_id").write.mode("append") \
    .partitionBy("completion_date") \
    .bucketBy(4, "match_id") \
    .saveAsTable("bootcamp.matches_bucketed")

# matches_details
matches_details_df.select(
    "match_id",
    "player_gamertag",
    f.to_number("player_total_kills", f.lit("999")).alias("player_total_kills")) \
    .write.mode("append")\
    .bucketBy(4, "match_id") \
    .saveAsTable("bootcamp.matches_details_bucketed")

# medals_matches_players
medals_matches_players_df.select(
    "match_id",
    "player_gamertag",
    "medal_id",
    f.to_number("count", f.lit("99")).alias("medal_count")) \
    .write.mode("append") \
    .bucketBy(4, "match_id") \
    .saveAsTable("bootcamp.medals_matches_players_bucketed")


# create temporary views to use in spark SQL
# matches
matches_df.createTempView("matches")

# matches details
matches_details_df.createTempView("matches_details")

# medals_matches_players
medals_matches_players_df.createTempView("medals_matches_players")

# clean medal_id in medals
spark.sql(
    """
        WITH cleaned_src AS (
            SELECT 
                name
                , CASE WHEN name = 'Team Takedown' THEN '2896365521'
                       WHEN name = 'Perfect Kill' THEN '1080468863'
                       ELSE medal_id
                  END AS medal_id
                , ROW_NUMBER() OVER(PARTITION BY name ORDER BY medal_id) row_
            FROM medals 
        )
    
        SELECT name, medal_id FROM cleaned_src WHERE row_ = 1 AND name IS NOT NULL
    """
).createOrReplaceTempView("dedupped_medals")

# map medals by match and player
spark.sql(
    """
        SELECT /*+ BROADCASTJOIN(dm) */
            mmp.match_id
            , mmp.player_gamertag
            , map_from_entries(collect_list(struct(dm.name, mmp.count))) medals_count_map
        FROM medals_matches_players mmp
        INNER JOIN dedupped_medals dm ON mmp.medal_id = dm.medal_id 
        GROUP BY 
            mmp.match_id
            , mmp.player_gamertag
    """
).createOrReplaceTempView("medals_count_map")

# clean maps before join
spark.sql(
    """
        SELECT * FROM maps WHERE mapid IS NOT NULL
    """
).createOrReplaceTempView("cleansed_maps")

# deactivate default broadcast join threshold
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")

# fact data to perform analytics
fact_matches_df = spark.sql(
    """
        SELECT /*+ BROADCASTJOIN(mcm, mp) */
            DATE(m.completion_date) AS match_completion_date
            , m.match_id
            , md.player_gamertag
            , m.playlist_id
            , mp.name AS map_name
            , md.player_total_kills
            , mcm.medals_count_map

        FROM matches m
        INNER JOIN matches_details md ON m.match_id = md.match_id 
        INNER JOIN medals_count_map mcm ON m.match_id = mcm.match_id AND md.player_gamertag = mcm.player_gamertag
        INNER JOIN cleansed_maps mp ON m.mapid = mp.mapid

    """
)

# explore different partitions for the aggregated table
fact_matches_df.repartition(5, f.col("match_completion_date"), f.col("map_name")) \
                          .sortWithinPartitions(f.col("match_completion_date"), f.col("map_name"))\
                          .write.mode("overwrite").saveAsTable("bootcamp.sorted_agg_medals_matches_players_05")

fact_matches_df.repartition(10, f.col("match_completion_date"), f.col("map_name")) \
                          .sortWithinPartitions(f.col("match_completion_date"), f.col("map_name"))\
                          .write.mode("overwrite").saveAsTable("bootcamp.sorted_agg_medals_matches_players_10")

fact_matches_df.repartition(5, f.col("match_completion_date"), f.col("map_name"), f.col("playlist_id")) \
                          .sortWithinPartitions(f.col("match_completion_date"), f.col("map_name"), f.col("playlist_id"))\
                          .write.mode("overwrite").saveAsTable("bootcamp.sorted_agg_medals_matches_players_2_05")

fact_matches_df.repartition(10, f.col("match_completion_date"), f.col("map_name"), f.col("playlist_id")) \
                          .sortWithinPartitions(f.col("match_completion_date"), f.col("map_name"), f.col("playlist_id"))\
                          .write.mode("overwrite").saveAsTable("bootcamp.sorted_agg_medals_matches_players_2_10")

# compare results of partitioning tables using different number of files and columns
spark.sql(
    """
        SELECT SUM(file_size_in_bytes) as size, COUNT(1) as num_files, 'sorted_map_only' 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_05.files

        UNION ALL

        SELECT SUM(file_size_in_bytes) as size, COUNT(1) as num_files, 'sorted_map_only' 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_10.files

        UNION ALL

        SELECT SUM(file_size_in_bytes) as size, COUNT(1) as num_files, 'sorted_map_playlist' 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05.files

        UNION ALL

        SELECT SUM(file_size_in_bytes) as size, COUNT(1) as num_files, 'sorted_map_playlist' 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_10.files
    """
).show()

# solving analytics questions

# which player averages the most kills
spark.sql(
    """
        SELECT player_gamertag, SUM(player_total_kills) / COUNT(match_id) avg_kills
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05
        GROUP BY 1
        ORDER BY avg_kills DESC
    """
).show()

# which playlist gets played the most?
spark.sql(
    """
        SELECT playlist_id, COUNT(DISTINCT match_id) matches 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05
        GROUP BY playlist_id
        ORDER BY matches DESC
    """
).show()

# which map gets played the most?
spark.sql(
    """
        SELECT map_name, COUNT(DISTINCT match_id) matches 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05
        GROUP BY 1
    """
).show()

# which map gets played the most?
spark.sql(
    """
        SELECT map_name, COUNT(DISTINCT match_id) matches 
        FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05
        GROUP BY 1
    """
).show()

# which map do players get the most Killing Spree medals on?
spark.sql(
    """
        WITH unnested_records AS (
            SELECT 
                match_id
                , map_name
                , explode(medals_count_map) 
            FROM demo.bootcamp.sorted_agg_medals_matches_players_2_05
        )

        SELECT map_name, COUNT(match_id) numb_medals
        FROM unnested_records
        WHERE key = 'Killing Spree'
        GROUP BY map_name
    """
).show()